from setuptools import setup

setup(name='inputlib',
      version='0.0.1',
      description='make inputting python urls easy!',
      url='https://github.com/therealadityashankar/inputlib',
      author='Aditya Shankar',
      author_email='aditniru@gmail.com',
      license='Unlicence',
      packages=['inputlib'],
      zip_safe=False)
